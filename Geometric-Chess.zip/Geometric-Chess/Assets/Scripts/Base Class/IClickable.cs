﻿

public interface IClickable {

	bool Inform<T>(T arg);
}
