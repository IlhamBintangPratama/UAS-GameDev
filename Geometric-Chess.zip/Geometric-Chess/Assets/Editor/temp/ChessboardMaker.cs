﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChessboardMaker {

	private int rows;
	private int cols;

	
}
